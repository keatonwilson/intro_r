# Assign a simple variable.
my_first_variable <- 2

# Get help about some functions.
# help(c)
# ?plot

# Create a basic plot.
x <- c(1,2,3)
y <- c(3,2,1)
plot(x, y)